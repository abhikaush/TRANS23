import { cacheMemory } from '../model/constant';
import { User } from '../model/user';

import { appUsersAuth } from '../security/app-users-auth';

import { DataService } from './data.service';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap, catchError } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material';
import { Booking } from '../model/booking';



const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class LoginSecurityService {
  securityObject: appUsersAuth = new appUsersAuth;
  constructor(private dataService: DataService, private http: HttpClient,private snackBar: MatSnackBar) { }

  //   login(entity:User):Observable<appUsersAuth>
  //   {



  //     Object.assign(this.securityObject,
  //     LOGIN_MOCKS.find(user=>user.userName.toLowerCase()==entity.userName.toLowerCase()

  //     //post method call

  //   )


  //     );  

  //     if(this.securityObject.userName!==" ")
  //       {
  // localStorage.setItem("bearerToken",this.securityObject.bearerToken);}
  //     return of<appUsersAuth>(this.securityObject);
  //   }

  public login(user: User): Observable<User> {
    this.resetSecurityObject();
  
    this.dataService.updateUser(new User());
   
    if (cacheMemory.get("loginId") != null)
      cacheMemory.set(<string>cacheMemory.get("loginId"), null);
    cacheMemory.set("loginId", null);//to be put in method
    cacheMemory.set("userDetails", null);//to be put in method

    return this.http.post<User>("/login", user, httpOptions).pipe(
      tap(data => {
        
        this.instantiateSecurityObject(data);
      
        this.dataService.updateUser(data);
      
       
      },
        error => {console.log(error)
        this.sneekBar("USER OR PASSWORD IS WRONG");
        this.dataService.updateUser(new User());
        }),
      catchError(this.handleError<User>("login")));
  }
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      //  this.log(`${operation} failed: ${error.messag}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  logout(): void {

    this.dataService.updateUser(new User());
    this.dataService.updatebooking(new Booking());
    this.resetSecurityObject();
    this.sneekBar("LOGGED OUT..");
   
    cacheMemory.set(<string>cacheMemory.get("loginId"), null);
    cacheMemory.set("loginId", null);//to be put in method
    cacheMemory.set("userDetails", null);//to be put in method

  }
  sneekBar(msg:string){
    this.snackBar.open(msg, "OK", {
      duration: 7000,
    });
  }

  resetSecurityObject(): void {
    this.securityObject.isRoleAdmin=false;
    this.securityObject.bearerToken = "";
    this.securityObject.userName = "";
    this.securityObject.isAuthinticated = false;
    this.securityObject.canViewVehicle = false;
    this.securityObject.canViewRide = false;
    this.securityObject.canViewWallet = false;
    this.securityObject.canViewSettings = false;

    localStorage.removeItem("bearerToken");
  }
  instantiateSecurityObject(data: User) {
    this.dataService.updateUser(data);
    this.securityObject.bearerToken = data.token;
    this.securityObject.userName = data.userName;
    this.securityObject.isAuthinticated = true;
    this.securityObject.canViewVehicle = true;
    this.securityObject.canViewRide = true;
    this.securityObject.canViewWallet = true;
    this.securityObject.canViewSettings = true;
    localStorage.setItem("bearerToken", this.securityObject.bearerToken);
    if(data.role=="ADMIN")
    {
      this.securityObject.isRoleAdmin=true;
    }
  }
}
