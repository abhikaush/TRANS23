


export class resetHome{
 public booked:boolean=false;
 public fareDetails:boolean;
 public rideDetails   :boolean;
}