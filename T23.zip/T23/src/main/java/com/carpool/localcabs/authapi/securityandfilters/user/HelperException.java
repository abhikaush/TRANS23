package com.carpool.localcabs.authapi.securityandfilters.user;

public class HelperException extends Exception {

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getFatalError() {
		return fatalError;
	}
	public void setFatalError(String fatalError) {
		this.fatalError = fatalError;
	}
	private String message;
	private String fatalError;
	
}
