package com.carpool.localcabs.authapi.securityandfilters.security;

import static com.auth0.jwt.algorithms.Algorithm.HMAC512;
import static com.carpool.localcabs.authapi.securityandfilters.security.SecurityConstants.EXPIRATION_TIME;
import static com.carpool.localcabs.authapi.securityandfilters.security.SecurityConstants.HEADER_STRING;
import static com.carpool.localcabs.authapi.securityandfilters.security.SecurityConstants.SECRET;
import static com.carpool.localcabs.authapi.securityandfilters.security.SecurityConstants.TOKEN_PREFIX;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.auth0.jwt.JWT;
import com.carpool.localcabs.entity.CacheMemory;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
import com.google.gson.Gson;

public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

	private AuthenticationManager authenticationManager;

	public JWTAuthenticationFilter(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
	}

	public Authentication attemptAuthentication(HttpServletRequest req, HttpServletResponse res)
			throws AuthenticationException {

		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
			//mapper.setVisibilityChecker(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
			
			com.carpool.localcabs.entity.User cred = mapper.readValue(req.getInputStream(),
					com.carpool.localcabs.entity.User.class);

			// res.setHeader(name, value);
			return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(cred.getUserName(),
					cred.getUserPassword(), new ArrayList<>()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	protected void successfulAuthentication(HttpServletRequest req, HttpServletResponse res, FilterChain chain,
			Authentication auth) throws IOException, ServletException {
		String token = JWT.create().withSubject(((User) auth.getPrincipal()).getUsername())
				.withExpiresAt(new Date(System.currentTimeMillis() + EXPIRATION_TIME)).sign(HMAC512(SECRET.getBytes()));
		res.addHeader(HEADER_STRING, TOKEN_PREFIX + token);
		String ss=(((User) auth.getPrincipal()).getUsername());
	CacheMemory.UserCache.get(ss).setToken(token);
		
		res.getWriter().write(getUserFromCache(((User) auth.getPrincipal()).getUsername()));
		res.getWriter().flush();
		res.getWriter().close();

	}

	private String getUserFromCache(String username) {
/*	GsonJsonParser g=new GsonJsonParser();*/
	Gson g=new Gson();
		
		if(null!=CacheMemory.UserCache.get(username))
		return g.toJson(CacheMemory.UserCache.get(username),com.carpool.localcabs.entity.User.class);
		else
			return null;

	}
}
