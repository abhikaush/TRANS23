package com.carpool.localcabs.service.serviceImpl;

import java.util.Date;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.carpool.localcabs.entity.Booking;
import com.carpool.localcabs.entity.User;
import com.carpool.localcabs.entity.Vehicle;
import com.carpool.localcabs.repository.BookingRepository;
import com.carpool.localcabs.repository.UserRepository;
import com.carpool.localcabs.service.BookingService;
@Service
public class BookingServiceImpl implements BookingService{
private BookingRepository bookingrepository;
private UserRepository userRepository;

public BookingServiceImpl(BookingRepository bookingRepository,UserRepository userRepository)
{
this.bookingrepository=bookingRepository;
this.userRepository=userRepository;
}





@Override
public List<Booking> getAllBooking() throws Exception{
	// TODO Auto-generated method stub
	return bookingrepository.findAll();
}

@Override
public ResponseEntity<Object> cancleRide(Booking booking) throws Exception{
	// TODO Auto-generated method stub
	
	bookingrepository.save(booking);
	
	return new ResponseEntity<Object>(HttpStatus.OK);
}

@Override
public Booking confirmRide(Booking booking) throws Exception{
	// TODO Auto-generated method stub
	//if booking is not cancelled or confirmed
	
	
	
	
	
	bookingrepository.save(booking);
	
	
	return booking;
}

@Override
public Booking getFareDetails(Booking booking,String UserID) throws Exception{
	// TODO Auto-generated method stub
	User user=new User();

	//user=userRepository.findById(UserID).orElse(user);
	//user.getAllbooking().add(booking);
	//userRepository.save(user);
	 bookingrepository.save(booking);
	 return  booking;
}
public Booking bookRide(Booking booking,String UserID) throws Exception{
	User user=new User();
	User us=new User();

	user=userRepository.findById(UserID).orElse(user);
	user.getAllbooking().add(booking);
	us=userRepository.save(user);
	 
	return us.getAllbooking().get(us.getAllbooking().size()-1);
}
}
