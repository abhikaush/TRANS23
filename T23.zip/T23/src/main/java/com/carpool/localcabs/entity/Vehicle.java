package com.carpool.localcabs.entity;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

import org.hibernate.annotations.GenericGenerator;

@Entity
@DiscriminatorColumn(name = "VehicleType")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Vehicle {
	@Id
	@GenericGenerator(name="Vehicle_Id_Generator" , strategy="com.carpool.localcabs.entity.VehicleIdGenerator")
	@GeneratedValue( generator="Vehicle_Id_Generator")
	private String vehicleId;
	private String owner;
	private String driver;
	private String ownerName;
	private String driverName;
	private String idProof;
	private String carType;
	private String regNo;
	private double farePerKm;
	private Integer offeringSeats;
	private String category;
	private String features;
	
	
	
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getDriverName() {
		return driverName;
	}
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	public String getIdProof() {
		return idProof;
	}
	public void setIdProof(String idProof) {
		this.idProof = idProof;
	}
	public String getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}
	
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getDriver() {
		return driver;
	}
	public void setDriver(String driver) {
		this.driver = driver;
	}
	public String getCarType() {
		return carType;
	}
	public void setCarType(String carType) {
		this.carType = carType;
	}
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	public double getFarePerKm() {
		return farePerKm;
	}
	public void setFarePerKm(double farePerKm) {
		this.farePerKm = farePerKm;
	}
	public Integer getOfferingSeats() {
		return offeringSeats;
	}
	public void setOfferingSeats(Integer offeringSeats) {
		this.offeringSeats = offeringSeats;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getFeatures() {
		return features;
	}
	public void setFeatures(String features) {
		this.features = features;
	}
	
	

}
