package com.carpool.localcabs.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.carpool.localcabs.entity.LocationAddress;
import com.carpool.localcabs.entity.User;

public interface UserController {
public	ResponseEntity<User> signUp(@RequestBody User user, HttpServletRequest request);
public ResponseEntity<Object> updateAddress(@PathVariable String type,@PathVariable String id, @RequestBody LocationAddress address);


}
