

package com.carpool.localcabs.google.maps;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import static com.carpool.localcabs.google.maps.PolyUtil.locationIndexOnEdgeOrPath;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

public class test {
	public static String js ="[{\"latitude\":37.769940000000005,\"longitude\""
			+ ":-122.44685000000001},{\"latitude\":37.76993,\"longitude\":"
			+ "-122.44693000000001},{\"latitude\":37.770010000000006,\"longitude\":"
			+ "-122.44695000000002},{\"latitude\":37.769800000000004,\"longitude\":"
			+ "-122.44859000000001},{\"latitude\":37.769380000000005,\"longitude\":"
			+ "-122.45188000000002},{\"latitude\":37.769180000000006,\"longitude\":"
			+ "-122.45344000000001},{\"latitude\":37.76917,\"longitude\":-122.45355}"
			+ ",{\"latitude\":37.76924,\"longitude\":-122.45356000000001},"
			+ "{\"latitude\":37.77085,\"longitude\":-122.45388000000001},"
			+ "{\"latitude\":37.77143,\"longitude\":-122.45399},"
			+ "{\"latitude\":37.7729,\"longitude\":-122.4543},"
			+ "{\"latitude\":37.77465,\"longitude\":-122.45466},"
			+ "{\"latitude\":37.77476,\"longitude\":-122.45470000000002},"
			+ "{\"latitude\":37.77472,\"longitude\":-122.45502},"
			+ "{\"latitude\":37.774800000000006,\"longitude\":-122.45504000000001},"
			+ "{\"latitude\":37.77478,\"longitude\":-122.45429000000001},"
			+ "{\"latitude\":37.77474,\"longitude\":-122.45462},"
			+ "{\"latitude\":37.77505,\"longitude\":-122.45467000000001},"
			+ "{\"latitude\":37.775510000000004,\"longitude\":-122.45477000000001},"
			+ "{\"latitude\":37.775710000000004,\"longitude\":-122.45483000000002},"
			+ "{\"latitude\":37.77635,\"longitude\":-122.45496000000001},{\"latitude\":37.777570000000004,"
			+ "\"longitude\":-122.45519000000002},{\"latitude\":37.77765,\"longitude\":-122.4552},"
			+ "{\"latitude\":37.77763,\"longitude\":-122.45529},{\"latitude\":37.777640000000005,\"longitude\":-122.45537000000002},{\"latitude\":37.777590000000004,\"longitude\":-122.45536000000001},{\"latitude\":37.7775,\"longitude\":-122.45606000000001},{\"latitude\":37.77722,\"longitude\":-122.45835000000001},{\"latitude\":37.777260000000005,\"longitude\":-122.45859000000002},{\"latitude\":37.777350000000006,\"longitude\":-122.45867000000001},{\"latitude\":37.77747,\"longitude\":-122.45901},{\"latitude\":37.77738,\"longitude\":-122.46081000000001},{\"latitude\":37.777240000000006,\"longitude\":-122.46402},{\"latitude\":37.777,\"longitude\":-122.46937000000001},{\"latitude\":37.776500000000006,\"longitude\":-122.48019000000001},{\"latitude\":37.775960000000005,\"longitude\":-122.49197000000001},{\"latitude\":37.775380000000006,\"longitude\":-122.50483000000001},{\"latitude\":37.775330000000004,\"longitude\":-122.50590000000001},{\"latitude\":37.77521,\"longitude\":-122.50589000000001},{\"latitude\":37.773540000000004,\"longitude\":-122.50577000000001},{\"latitude\":37.773540000000004,\"longitude\":-122.50582000000001},{\"latitude\":37.773430000000005,\"longitude\":-122.50582000000001},{\"latitude\":37.77163,\"longitude\":-122.50569000000002},{\"latitude\":37.77160000000001,\"longitude\":-122.50632000000002},{\"latitude\":37.77158,\"longitude\":-122.50674000000001},{\"latitude\":37.771530000000006,\"longitude\":-122.50789},{\"latitude\":37.77141,\"longitude\":-122.51055000000001},{\"latitude\":37.771370000000005,\"longitude\":-122.51118000000001},{\"latitude\":37.771370000000005,\"longitude\":-122.51124000000002},{\"latitude\":37.77136,\"longitude\":-122.51131000000001},{\"latitude\":37.770880000000005,\"longitude\":-122.51125},{\"latitude\":37.77062,\"longitude\":-122.51123000000001},{\"latitude\":37.770540000000004,\"longitude\":-122.51124000000002},{\"latitude\":37.770410000000005,\"longitude\":-122.51129000000002},{\"latitude\":37.77038,\"longitude\":-122.51115000000001},{\"latitude\":37.770320000000005,\"longitude\":-122.51116},{\"latitude\":37.77015,\"longitude\":-122.51117},{\"latitude\":37.768390000000004,\"longitude\":-122.51093000000002}]";

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		// TODO Auto-generated method stub
		List< LatLng> l=new ArrayList<>();
		Gson g =new Gson();
	LatLng latln=new LatLng(37.77976966877763, -122.478985529);
//List<LatLng> s=	g.fromJson(js, List.class);
List<LatLng> s1=new ArrayList<>();
ObjectMapper mapper = new ObjectMapper();
List<LatLng> s=mapper.readValue(js,mapper.getTypeFactory().constructCollectionType(List.class, LatLng.class));
System.out.println(s);

	
System.out.println(locationIndexOnEdgeOrPath(latln, s, false, false, 0.01));
		
	}

}
