package com.carpool.localcabs.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.carpool.localcabs.entity.Vehicle;

public interface RideSearchService {
	public ResponseEntity<Object> saveVehicle(Vehicle ride) throws Exception;
	
	public List<Vehicle> getVehicleList() throws Exception;
	public Vehicle getVEhicleByRegno(String regNo) throws Exception;
}
