package com.carpool.localcabs.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.carpool.localcabs.entity.User;

public interface ApplicationUserRepository extends JpaRepository<User, Long>{
	User findByUserEmail(String userEmail);
	User findByUserPhoneNumber(long phone);
}
