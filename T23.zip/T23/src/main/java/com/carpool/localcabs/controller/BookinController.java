package com.carpool.localcabs.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.carpool.localcabs.entity.Booking;
import com.carpool.localcabs.entity.User;
import com.carpool.localcabs.entity.Vehicle;

public interface BookinController {
	public List<Booking> getAllBooking();
	public ResponseEntity<Object> cancleRide(@RequestBody Booking booking);
	public Booking confirmRide(@RequestBody Booking booking);
	public Booking getFareDetails(@PathVariable String userID,@RequestBody Booking booking);
	public Booking bookRide(@PathVariable String UserID,@RequestBody Booking booking);

}
