package com.carpool.localcabs.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.carpool.localcabs.entity.User;
import com.carpool.localcabs.entity.Vehicle;

public interface RideController {
	public ResponseEntity<Object> saveVehicle(@RequestBody Vehicle ride);
	public List<Vehicle> getVehicleList();
	public Vehicle getVEhicleByRegno(@RequestBody String regNo);
}
