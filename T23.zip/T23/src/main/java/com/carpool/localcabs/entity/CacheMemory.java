package com.carpool.localcabs.entity;

import java.util.HashMap;
import java.util.Map;

public class CacheMemory {

	public static Map<String, User> UserCache=new HashMap<>();
}
