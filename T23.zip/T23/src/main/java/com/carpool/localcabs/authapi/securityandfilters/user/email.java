package com.carpool.localcabs.authapi.securityandfilters.user;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class email {
	@Id
	
private int emailid;
private String email;

public int getEmailid() {
	return emailid;
}
public void setEmailid(int emailid) {
	this.emailid = emailid;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}

}
