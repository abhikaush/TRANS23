package com.carpool.localcabs.service.serviceImpl;

import java.util.List;

import javax.management.RuntimeErrorException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.stereotype.Service;

import com.carpool.localcabs.entity.User;
import com.carpool.localcabs.entity.Vehicle;
import com.carpool.localcabs.repository.RideSearchRepository;
import com.carpool.localcabs.service.RideSearchService;

@Service
public class RideSearchServiceImpl implements RideSearchService{
private RideSearchRepository repository;
private User user;
public RideSearchServiceImpl(RideSearchRepository repository) {
	
	this.repository = repository;
}
@Override
public ResponseEntity<Object> saveVehicle(Vehicle ride) throws Exception{
	// TODO Auto-generated method stub
	
	if(!isVehicleAlreadyPresent(ride))
	{
		repository.save(ride);
		return new ResponseEntity<Object>(HttpStatus.OK);
	}
	else
	{
		throw new RuntimeException("Vehicle already present");
	}
	
}

public boolean isVehicleAlreadyPresent(Vehicle vehicle ) throws Exception
{
	return (null!=repository.findByregNo(vehicle.getRegNo()))? true :false;
}
@Override
public List<Vehicle> getVehicleList() throws Exception{
	// TODO Auto-generated method stub
	return repository.findAll();
}
@Override
public Vehicle getVEhicleByRegno(String regNo) throws Exception  {
	// TODO Auto-generated method stub
	return repository.findByregNo(regNo);
}

}
