package com.carpool.localcabs.service;

import org.springframework.http.ResponseEntity;

import com.carpool.localcabs.entity.LocationAddress;
import com.carpool.localcabs.entity.User;

public interface UserService {
public ResponseEntity<User> save(User user) throws Exception;
public void updateAddress(LocationAddress locationAddress,String userId,String type) throws Exception;
}
