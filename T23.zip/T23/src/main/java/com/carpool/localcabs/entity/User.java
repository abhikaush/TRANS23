package com.carpool.localcabs.entity;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

@Entity
public class User {
	@Id
	@GenericGenerator(name = "User_Id_Generator", strategy = "com.carpool.localcabs.entity.UserIdGenerator")
	@GeneratedValue(generator = "User_Id_Generator")
	private String userId;

	private String userName;

	private Long userPhoneNumber;
	private String userEmail;

	private String userPassword;

	@OneToMany(cascade = CascadeType.MERGE

	)
	@LazyCollection(LazyCollectionOption.FALSE)
	private List<Booking> allbooking=new LinkedList<Booking>();
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "homeAddress")
	private LocationAddress homeAddress;

	private boolean isUserHomeaddressFilled;

	@Transient
	private String token = "";
	private String role;

	

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<Booking> getAllbooking() {
		return allbooking;
	}

	public void setAllbooking(List<Booking> allbooking) {
		this.allbooking = allbooking;
	}

	

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getUserPhoneNumber() {
		return userPhoneNumber;
	}

	public void setUserPhoneNumber(Long userPhoneNumber) {
		this.userPhoneNumber = userPhoneNumber;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public LocationAddress getHomeAddress() {
		return homeAddress;
	}

	public void setHomeAddress(LocationAddress homeAddress) {
		this.homeAddress = homeAddress;
	}

	public boolean isUserHomeaddressFilled() {
		return isUserHomeaddressFilled;
	}

	public void setUserHomeaddressFilled(boolean isUserHomeaddressFilled) {
		this.isUserHomeaddressFilled = isUserHomeaddressFilled;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}
