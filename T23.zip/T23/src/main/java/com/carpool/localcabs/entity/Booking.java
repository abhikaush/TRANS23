package com.carpool.localcabs.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Booking implements Cloneable{
	@Id
	@GenericGenerator(name = "Booking_Id_Generator", strategy = "com.carpool.localcabs.entity.BookingIdGenerator")
	@GeneratedValue(generator = "Booking_Id_Generator")
	private String id;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="ride")
	
	private Ride ride;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="vehicle")
	private Vehicle vehicle;
	private String status;
	//@Temporal(TemporalType.DATE)
	private String bookingDate;
	//@Temporal(TemporalType.DATE)
	private String confirmDate;
	//@Temporal(TemporalType.DATE)
	private String cancleDate;
	private boolean confirmed=false;
	private boolean canCancle=true;
	 @OneToOne(cascade=CascadeType.ALL)
	    @JoinColumn(name="fare")
	private Fare fare;
	 private boolean roundTrip;
	 private String startRideKm;
	 private String  endRideKm;
	 @Transient
	 private boolean select;
	 public Object clone() throws
     CloneNotSupportedException 
{ 
return super.clone(); 
} 
	 
	 
	
	public boolean isSelect() {
		return select;
	}



	public void setSelect(boolean select) {
		this.select = select;
	}



	public String getStartRideKm() {
		return startRideKm;
	}


	public void setStartRideKm(String startRideKm) {
		this.startRideKm = startRideKm;
	}


	public String getEndRideKm() {
		return endRideKm;
	}


	public void setEndRideKm(String endRideKm) {
		this.endRideKm = endRideKm;
	}


	public boolean isConfirmed() {
		return confirmed;
	}


	public void setConfirmed(boolean confirmed) {
		this.confirmed = confirmed;
	}


	public boolean isRoundTrip() {
		return roundTrip;
	}


	public void setRoundTrip(boolean roundTrip) {
		this.roundTrip = roundTrip;
	}


	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Fare getFare() {
		return fare;
	}
	public void setFare(Fare fare) {
		this.fare = fare;
	}

	
	
	public String getBookingDate() {
		return bookingDate;
	}


	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}


	public String getConfirmDate() {
		return confirmDate;
	}


	public void setConfirmDate(String confirmDate) {
		this.confirmDate = confirmDate;
	}


	public String getCancleDate() {
		return cancleDate;
	}


	public void setCancleDate(String cancleDate) {
		this.cancleDate = cancleDate;
	}


	public boolean isCanCancle() {
		return canCancle;
	}


	public void setCanCancle(boolean canCancle) {
		this.canCancle = canCancle;
	}


	public Ride getRide() {
		return ride;
	}

	public void setRide(Ride ride) {
		this.ride = ride;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
