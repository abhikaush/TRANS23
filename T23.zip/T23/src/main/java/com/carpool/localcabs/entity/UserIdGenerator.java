package com.carpool.localcabs.entity;

import java.io.Serializable;
import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class UserIdGenerator implements IdentifierGenerator{

	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {

        String prefix = "USER_";
       try{
    	   Random rand = new Random();
    	   int random=rand.nextInt();
    
                int id=Constants.UserId;
                String generatedId = prefix +String.format("%02d", random)+new Integer(id++).toString();
                System.out.println("Generated Id: " + generatedId);
                return generatedId;
            }
         catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        return null;
	}

}
