package com.carpool.localcabs.controller.controllerImpl;



import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.carpool.localcabs.controller.UserController;
import com.carpool.localcabs.entity.LocationAddress;
import com.carpool.localcabs.entity.User;
import com.carpool.localcabs.service.UserService;

@RestController
@RequestMapping("api/users")
public class UserControllerImpl  implements UserController {
private UserService userService;
private BCryptPasswordEncoder bCryptPasswordEncoder;
private static  Logger logger=org.apache.logging.log4j.LogManager.getLogger(UserControllerImpl.class.getName());

public UserControllerImpl(UserService userService,
        BCryptPasswordEncoder bCryptPasswordEncoder) {
this.userService = userService;
this.bCryptPasswordEncoder = bCryptPasswordEncoder;

}


@PostMapping("/sign-up")
public ResponseEntity<User> signUp(@RequestBody User user, HttpServletRequest request) {

	user.setUserPassword(bCryptPasswordEncoder.encode(user.getUserPassword()));
	
	try {
		//logger.info(user.getUserId()+ " "+user.getUserName()+ "USER REGSTERED SUCCESSFULLY");
		return userService.save(user);
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		logger.error("signUp "+e.getMessage());
	
		 return new ResponseEntity<User>(HttpStatus.FORBIDDEN);
			      
	}
	
	
}

@PutMapping("/{type}/{id}")
public ResponseEntity<Object> updateAddress(@PathVariable String type,@PathVariable String id, @RequestBody LocationAddress address)
{
    try {
		userService.updateAddress(address, id, type);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		logger.error("updateAddress "+e.getMessage());
	}
	System.out.println(type +id);
	return new ResponseEntity<Object>(HttpStatus.OK);
}

}
