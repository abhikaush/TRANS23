package com.carpool.localcabs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.carpool.localcabs.entity.User;

public interface UserRepository extends JpaRepository<User, String> {
	User findByUserEmail(String userEmail);
	User findByUserPhoneNumber(Long phoneNumber);
}
