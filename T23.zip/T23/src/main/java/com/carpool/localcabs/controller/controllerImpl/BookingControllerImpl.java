package com.carpool.localcabs.controller.controllerImpl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.carpool.localcabs.controller.BookinController;
import com.carpool.localcabs.entity.Booking;
import com.carpool.localcabs.entity.User;
import com.carpool.localcabs.entity.Vehicle;
import com.carpool.localcabs.service.BookingService;
@RestController
@RequestMapping("api/booking")
public class BookingControllerImpl implements BookinController{
private BookingService service;
private static Logger logger=LogManager.getFormatterLogger(BookingControllerImpl.class.getName());
public BookingControllerImpl(BookingService service)
{
	this.service=service;
}



@PostMapping("/fareDetails/{UserID}")
public Booking getFareDetails(@PathVariable String UserID, @RequestBody Booking booking) {
	// TODO Auto-generated method stub
	try {
		//booking.setVehicle(null);
		return service.getFareDetails(booking,UserID);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		logger.error("getFareDetails" +e.getMessage());
		return booking;
	}
}






@Override
@GetMapping("/getAllBooking")
public List<Booking> getAllBooking() {
	// TODO Auto-generated method stub
	try {
		return service.getAllBooking();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		logger.error("getAllBooking"+e.getMessage());
		return null;
	}
}

@Override
@PostMapping("/cancleRide")
public ResponseEntity<Object> cancleRide(@RequestBody Booking booking) {
	// TODO Auto-generated method stub
	try {
		return service.cancleRide(booking);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		logger.error("cancleRide "+e.getMessage());
		return new ResponseEntity<Object>(HttpStatus.FORBIDDEN);
	}
}

@Override
@PostMapping("/confirmRide")
public Booking confirmRide(@RequestBody Booking booking) {
	// TODO Auto-generated method stub
	try {
		return service.confirmRide(booking);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		logger.error("confirmRide "+e.getMessage());
		return booking;
	}
}

@Override
@PostMapping("/book/{UserID}")
public Booking bookRide(@PathVariable String UserID,@RequestBody Booking booking) {
	// TODO Auto-generated method stub
	try {
		//booking.setVehicle(null);
		return service.bookRide(booking, UserID);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		logger.error("bookRide "+e.getMessage());
		return booking;
	}
}
}
