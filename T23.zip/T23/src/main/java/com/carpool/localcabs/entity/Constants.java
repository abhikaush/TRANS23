package com.carpool.localcabs.entity;

public class Constants {

	public static Integer UserId=22;
	public static Integer VehicleId=22;
	public static Integer RideId=22;
	
}
