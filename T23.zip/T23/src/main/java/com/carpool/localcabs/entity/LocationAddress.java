package com.carpool.localcabs.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class LocationAddress {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="Location_seq")
	@SequenceGenerator(
	    name="Location_seq",
	    sequenceName="Location_sequence",
	    allocationSize=20
	)
	 
	private Integer LocationId;
	private String formattedAddress;

	
	private double latitude;// temp

	private double longitude;// temp






	public Integer getLocationId() {
		return LocationId;
	}

	public void setLocationId(Integer locationId) {
		LocationId = locationId;
	}

	public String getFormattedAddress() {
		return formattedAddress;
	}

	public void setFormattedAddress(String formattedAddress) {
		this.formattedAddress = formattedAddress;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

}
