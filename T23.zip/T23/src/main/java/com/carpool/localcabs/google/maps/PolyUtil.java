package com.carpool.localcabs.google.maps;

import static com.carpool.localcabs.google.maps.MathUtil.EARTH_RADIUS;
import static com.carpool.localcabs.google.maps.MathUtil.clamp;
import static com.carpool.localcabs.google.maps.MathUtil.hav;
import static com.carpool.localcabs.google.maps.MathUtil.havDistance;
import static com.carpool.localcabs.google.maps.MathUtil.havFromSin;
import static com.carpool.localcabs.google.maps.MathUtil.inverseMercator;
import static com.carpool.localcabs.google.maps.MathUtil.mercator;
import static com.carpool.localcabs.google.maps.MathUtil.sinFromHav;
import static com.carpool.localcabs.google.maps.MathUtil.sinSumFromHav;
import static com.carpool.localcabs.google.maps.MathUtil.wrap;
import static java.lang.Math.PI;
import static java.lang.Math.cos;
import static java.lang.Math.max;
import static java.lang.Math.min;
import static java.lang.Math.sin;
import static java.lang.Math.sqrt;
import static java.lang.Math.toRadians;

import java.util.List;

public class PolyUtil {

	/**
	 * Returns sin(initial bearing from (lat1,lng1) to (lat3,lng3) minus initial
	 * bearing from (lat1, lng1) to (lat2,lng2)).
	 */
	private static double sinDeltaBearing(double lat1, double lng1, double lat2, double lng2, double lat3,
			double lng3) {
		double sinLat1 = sin(lat1);
		double cosLat2 = cos(lat2);
		double cosLat3 = cos(lat3);
		double lat31 = lat3 - lat1;
		double lng31 = lng3 - lng1;
		double lat21 = lat2 - lat1;
		double lng21 = lng2 - lng1;
		double a = sin(lng31) * cosLat3;
		double c = sin(lng21) * cosLat2;
		double b = sin(lat31) + 2 * sinLat1 * cosLat3 * hav(lng31);
		double d = sin(lat21) + 2 * sinLat1 * cosLat2 * hav(lng21);
		double denom = (a * a + b * b) * (c * c + d * d);
		return denom <= 0 ? 1 : (a * d - b * c) / sqrt(denom);
	}

	private static boolean isOnSegmentGC(double lat1, double lng1, double lat2, double lng2, double lat3, double lng3,
			double havTolerance) {
		double havDist13 = havDistance(lat1, lat3, lng1 - lng3);
		if (havDist13 <= havTolerance) {
			return true;
		}
		double havDist23 = havDistance(lat2, lat3, lng2 - lng3);
		if (havDist23 <= havTolerance) {
			return true;
		}
		double sinBearing = sinDeltaBearing(lat1, lng1, lat2, lng2, lat3, lng3);
		double sinDist13 = sinFromHav(havDist13);
		double havCrossTrack = havFromSin(sinDist13 * sinBearing);
		if (havCrossTrack > havTolerance) {
			return false;
		}
		double havDist12 = havDistance(lat1, lat2, lng1 - lng2);
		double term = havDist12 + havCrossTrack * (1 - 2 * havDist12);
		if (havDist13 > term || havDist23 > term) {
			return false;
		}
		if (havDist12 < 0.74) {
			return true;
		}
		double cosCrossTrack = 1 - 2 * havCrossTrack;
		double havAlongTrack13 = (havDist13 - havCrossTrack) / cosCrossTrack;
		double havAlongTrack23 = (havDist23 - havCrossTrack) / cosCrossTrack;
		double sinSumAlongTrack = sinSumFromHav(havAlongTrack13, havAlongTrack23);
		return sinSumAlongTrack > 0; // Compare with half-circle == PI using sign of sin().
	}

	/**
	 * Computes whether (and where) a given point lies on or near a polyline, within
	 * a specified tolerance. If closed, the closing segment between the last and
	 * first points of the polyline is not considered.
	 * 
	 * @param point
	 *            our needle
	 * @param poly
	 *            our haystack
	 * @param closed
	 *            whether the polyline should be considered closed by a segment
	 *            connecting the last point back to the first one
	 * @param geodesic
	 *            the polyline is composed of great circle segments if geodesic is
	 *            true, and of Rhumb segments otherwise
	 * @param toleranceEarth
	 *            tolerance (in meters)
	 * @return -1 if point does not lie on or near the polyline. 0 if point is
	 *         between poly[0] and poly[1] (inclusive), 1 if between poly[1] and
	 *         poly[2], ..., poly.size()-2 if between poly[poly.size() - 2] and
	 *         poly[poly.size() - 1]
	 */
	public static int locationIndexOnEdgeOrPath(LatLng point, List<LatLng> poly, boolean closed, boolean geodesic,
			double toleranceEarth) {
		int size = poly.size();
		if (size == 0) {
			return -1;
		}
		double tolerance = toleranceEarth / EARTH_RADIUS;
		double havTolerance = hav(tolerance);
		double lat3 = toRadians(point.latitude);
		double lng3 = toRadians(point.longitude);
		LatLng prev = poly.get(closed ? size - 1 : 0);
		double lat1 = toRadians(prev.latitude);
		double lng1 = toRadians(prev.longitude);
		int idx = 0;
		if (geodesic) {
			for (LatLng point2 : poly) {
				double lat2 = toRadians(point2.latitude);
				double lng2 = toRadians(point2.longitude);
				if (isOnSegmentGC(lat1, lng1, lat2, lng2, lat3, lng3, havTolerance)) {
					return Math.max(0, idx - 1);
				}
				lat1 = lat2;
				lng1 = lng2;
				idx++;
			}
		} else {
			// We project the points to mercator space, where the Rhumb segment is a
			// straight line,
			// and compute the geodesic distance between point3 and the closest point on the
			// segment. This method is an approximation, because it uses "closest" in
			// mercator
			// space which is not "closest" on the sphere -- but the error is small because
			// "tolerance" is small.
			double minAcceptable = lat3 - tolerance;
			double maxAcceptable = lat3 + tolerance;
			double y1 = mercator(lat1);
			double y3 = mercator(lat3);
			double[] xTry = new double[3];
			for (LatLng point2 : poly) {
				double lat2 = toRadians(point2.latitude);
				double y2 = mercator(lat2);
				double lng2 = toRadians(point2.longitude);
				if (max(lat1, lat2) >= minAcceptable && min(lat1, lat2) <= maxAcceptable) {
					// We offset longitudes by -lng1; the implicit x1 is 0.
					double x2 = wrap(lng2 - lng1, -PI, PI);
					double x3Base = wrap(lng3 - lng1, -PI, PI);
					xTry[0] = x3Base;
					// Also explore wrapping of x3Base around the world in both directions.
					xTry[1] = x3Base + 2 * PI;
					xTry[2] = x3Base - 2 * PI;
					for (double x3 : xTry) {
						double dy = y2 - y1;
						double len2 = x2 * x2 + dy * dy;
						double t = len2 <= 0 ? 0 : clamp((x3 * x2 + (y3 - y1) * dy) / len2, 0, 1);
						double xClosest = t * x2;
						double yClosest = y1 + t * dy;
						double latClosest = inverseMercator(yClosest);
						double havDist = havDistance(lat3, latClosest, x3 - xClosest);
						if (havDist < havTolerance) {
							return Math.max(0, idx - 1);
						}
					}
				}
				lat1 = lat2;
				lng1 = lng2;
				y1 = y2;
				idx++;
			}
		}
		return -1;
	}

}
