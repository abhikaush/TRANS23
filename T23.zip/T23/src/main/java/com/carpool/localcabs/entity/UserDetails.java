package com.carpool.localcabs.entity;

import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.GenericGenerator;

public class UserDetails {
	
	private String userDetailId;
	
	private String userName;
	
	private Integer userPnoneNumber;
	private String userEmail;
	private String companyName;
 
	private boolean isUserVerified;
	

	public boolean isUserVerified() {
		return isUserVerified;
	}

	public void setUserVerified(boolean isUserVerified) {
		this.isUserVerified = isUserVerified;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}



	public String getUserDetailId() {
		return userDetailId;
	}

	public void setUserDetailId(String userDetailId) {
		this.userDetailId = userDetailId;
	}

	public Integer getUserPnoneNumber() {
		return userPnoneNumber;
	}

	public void setUserPnoneNumber(Integer userPnoneNumber) {
		this.userPnoneNumber = userPnoneNumber;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	
}
