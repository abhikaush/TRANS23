package com.carpool.localcabs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.carpool.localcabs.entity.Booking;

public interface BookingRepository extends JpaRepository<Booking, String>{

}
