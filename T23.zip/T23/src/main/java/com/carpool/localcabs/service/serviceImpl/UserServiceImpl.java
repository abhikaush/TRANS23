package com.carpool.localcabs.service.serviceImpl;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.carpool.localcabs.entity.LocationAddress;
import com.carpool.localcabs.entity.User;
import com.carpool.localcabs.repository.UserRepository;
import com.carpool.localcabs.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	 HttpHeaders responseHeaders = new HttpHeaders();
	UserRepository userRepository;

	public UserServiceImpl(UserRepository userRepository) {

		this.userRepository = userRepository;
	}

	@Override
	public ResponseEntity<User> save(User user) throws Exception{
		
		if (null != user.getUserEmail() && null != user.getUserPhoneNumber()
			&&	user.getUserEmail().trim().length() != 0
			&& user.getUserPhoneNumber().toString().trim().length() != 0) {
			
			if(!isPhoneNumberOrEmailAlreadyExist(user))
			{
				
				userRepository.save(user);
				 HttpHeaders responseHeaders = new HttpHeaders();
				    responseHeaders.set("user", 
				      "success reg");
				   
				    return ResponseEntity.status(HttpStatus.OK)
				      .headers(responseHeaders)
				      .body(user);
			
			}
			else {
				
				    responseHeaders.set("user", 
				      "\"EMAIL OR PHONE NUMBER ALREADY EXISTS\"");
				 
				    return ResponseEntity.status(HttpStatus.FORBIDDEN)
				      .headers(responseHeaders)
				      .body(user);
			
			}

		}
		return ResponseEntity.status(HttpStatus.FORBIDDEN)
			      .headers(responseHeaders)
			      .body(user);
	}
	public void updateAddress(LocationAddress locationAddress,String userId,String type) throws Exception
	{
	User user=new User();
	user=	userRepository.findById(userId).orElse(user);
	
		user.setUserHomeaddressFilled(true);
		user.setHomeAddress(locationAddress);
	
	
	userRepository.save(user);
	}
	
	private boolean isPhoneNumberOrEmailAlreadyExist(User user) throws Exception
	{
		if(null!=userRepository.findByUserEmail(user.getUserEmail())) {
			System.out.println("USer Email Exists");
		return true;
		}
		else
		
		if(null!=userRepository.findByUserPhoneNumber(user.getUserPhoneNumber())) {
			System.out.println("USer phone Exists");
			return true;
			}
			else {
			return false;
			}
		
	}
}
