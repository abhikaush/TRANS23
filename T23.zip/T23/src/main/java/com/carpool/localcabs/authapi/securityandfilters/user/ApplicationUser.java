package com.carpool.localcabs.authapi.securityandfilters.user;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class ApplicationUser {

	@Id
	@GenericGenerator(name="sequence_App_id" , strategy="com.carpool.localcabs.authapi.securityandfilters.user.IdGenerator")
	@GeneratedValue( generator="sequence_App_id")
    private String userid;
    private String username;
    private String password;
    @OneToMany(
            cascade = CascadeType.ALL
           
        )

    private List<email> email;

   
	public List<email> getEmail() {
		return email;
	}

	

	

    public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public void setEmail(List<email> email) {
		this.email = email;
	}

	public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }	
	
	
}
