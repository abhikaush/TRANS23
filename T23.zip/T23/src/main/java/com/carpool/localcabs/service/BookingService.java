package com.carpool.localcabs.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.carpool.localcabs.entity.Booking;
import com.carpool.localcabs.entity.User;
import com.carpool.localcabs.entity.Vehicle;

public interface BookingService {

public List<Booking> getAllBooking() throws Exception;
public ResponseEntity<Object> cancleRide(Booking booking) throws Exception;
public Booking confirmRide(Booking booking) throws Exception;
public Booking getFareDetails(Booking booking,String UserID) throws Exception;
public Booking bookRide(Booking booking,String UserID) throws Exception;
}
