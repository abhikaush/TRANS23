package com.carpool.localcabs.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

@Entity
@DiscriminatorColumn(name = "RideType")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Ride {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Ride_seq")
	@SequenceGenerator(name = "Ride_seq", sequenceName = "Ride_sequence", allocationSize = 20)

	private Integer rideId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "startRide")
	private LocationAddress startRide;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "endRide")
	private LocationAddress endRide;

	private String enddate;

	private String startdate;

private String extraComments;


public Integer getRideId() {
	return rideId;
}
public void setRideId(Integer rideId) {
	this.rideId = rideId;
}
public LocationAddress getStartRide() {
	return startRide;
}
public void setStartRide(LocationAddress startRide) {
	this.startRide = startRide;
}
public LocationAddress getEndRide() {
	return endRide;
}
public void setEndRide(LocationAddress endRide) {
	this.endRide = endRide;
}


public String getEnddate() {
	return enddate;
}
public void setEnddate(String enddate) {
	this.enddate = enddate;
}
public String getStartdate() {
	return startdate;
}
public void setStartdate(String startdate) {
	this.startdate = startdate;
}
public String getExtraComments() {
	return extraComments;
}
public void setExtraComments(String extraComments) {
	this.extraComments = extraComments;
}

	
}
