package com.carpool.localcabs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.carpool.localcabs.entity.Vehicle;

public interface RideSearchRepository extends JpaRepository<Vehicle, String>{

	Vehicle findByregNo(String regNo);
}
