package com.carpool.localcabs.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;
@Entity
public class Fare {
	@Id
	@GenericGenerator(name = "Fare_Id_Generator", strategy = "com.carpool.localcabs.entity.FareIdGenerator")
	@GeneratedValue(generator = "Fare_Id_Generator")
	private String fareId;
private double estimatedFare;
private double totalFare;
private double driverAllowance;
private double perHrAllowance;
private double extraKmFee;
private double totalKM;
private double totalKMTravelled;

public String getFareId() {
	return fareId;
}
public void setFareId(String fareId) {
	this.fareId = fareId;
}
public double getEstimatedFare() {
	return estimatedFare;
}
public void setEstimatedFare(double estimatedFare) {
	this.estimatedFare = estimatedFare;
}
public double getTotalFare() {
	return totalFare;
}
public void setTotalFare(double totalFare) {
	this.totalFare = totalFare;
}
public double getDriverAllowance() {
	return driverAllowance;
}
public void setDriverAllowance(double driverAllowance) {
	this.driverAllowance = driverAllowance;
}
public double getPerHrAllowance() {
	return perHrAllowance;
}
public void setPerHrAllowance(double perHrAllowance) {
	this.perHrAllowance = perHrAllowance;
}
public double getExtraKmFee() {
	return extraKmFee;
}
public void setExtraKmFee(double extraKmFee) {
	this.extraKmFee = extraKmFee;
}
public double getTotalKM() {
	return totalKM;
}
public void setTotalKM(double totalKM) {
	this.totalKM = totalKM;
}
public double getTotalKMTravelled() {
	return totalKMTravelled;
}
public void setTotalKMTravelled(double totalKMTravelled) {
	this.totalKMTravelled = totalKMTravelled;
}

}
