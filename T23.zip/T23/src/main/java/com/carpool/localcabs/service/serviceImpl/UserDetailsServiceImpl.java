package com.carpool.localcabs.service.serviceImpl;

import static java.util.Collections.emptyList;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.carpool.localcabs.entity.CacheMemory;
import com.carpool.localcabs.repository.ApplicationUserRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    private ApplicationUserRepository applicationUserRepository;

    public UserDetailsServiceImpl(ApplicationUserRepository applicationUserRepository) {
        this.applicationUserRepository = applicationUserRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username1) throws UsernameNotFoundException {
    	com.carpool.localcabs.entity.User applicationUser=null;
    	if(username1.contains("@"))
    		{applicationUser  = applicationUserRepository.findByUserEmail(username1);}
    	else
    		{applicationUser  = applicationUserRepository.findByUserPhoneNumber(Long.parseLong(username1));}
    	if (applicationUser == null) {
            throw new UsernameNotFoundException(username1);
        }
    	storeUserInCache(applicationUser);
        return new User(applicationUser.getUserName(), applicationUser.getUserPassword(), emptyList());
    }

	private void storeUserInCache(com.carpool.localcabs.entity.User applicationUser) {
		// TODO Auto-generated method stub
		CacheMemory.UserCache.put(applicationUser.getUserName(), applicationUser);
	}
}