package com.carpool.localcabs.controller.controllerImpl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.carpool.localcabs.controller.RideController;
import com.carpool.localcabs.entity.Vehicle;
import com.carpool.localcabs.service.RideSearchService;

@RestController
@RequestMapping("api/ride")
public class RideControllerImpl implements RideController {
	private static Logger logger=LogManager.getLogger(RideControllerImpl.class.getName());
	private RideSearchService rideSearchService;

	public RideControllerImpl(RideSearchService rideSearchService) {
		
		this.rideSearchService = rideSearchService;
	} 
	
	
	@PostMapping("/addVehicle")
	public ResponseEntity<Object> saveVehicle(@RequestBody Vehicle ride) {
		// TODO Auto-generated method stub
		
		try {
			return rideSearchService.saveVehicle(ride);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("saveVehicle "+e.getMessage());
			return new ResponseEntity<Object>(HttpStatus.FORBIDDEN);
		}
	}

	
	@GetMapping("/getAllVehicle")
	public List<Vehicle> getVehicleList() {
		// TODO Auto-generated method stub
		try {
			return rideSearchService.getVehicleList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("getVehicleList "+e.getMessage());
			return null;
		}
	}

	@GetMapping("/getSingleVEhicle")
	public Vehicle getVEhicleByRegno(String regNo) {
		// TODO Auto-generated method stub
		try {
			return rideSearchService.getVEhicleByRegno(regNo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("getVEhicleByRegno "+e.getMessage());
			return null;
		}
	}
	
}
