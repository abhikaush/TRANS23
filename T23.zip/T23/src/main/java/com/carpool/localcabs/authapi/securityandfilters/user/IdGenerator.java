package com.carpool.localcabs.authapi.securityandfilters.user;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

import com.carpool.localcabs.entity.Constants;

public class IdGenerator implements IdentifierGenerator{



	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) throws HibernateException {

        String prefix = "USER_";
       try{
    	   Random r=new Random();
    	   
                String generatedId = prefix + new Integer(r.nextInt(394)+Constants.RideId++).toString().substring(4);
                System.out.println("Generated Id: " + generatedId);
                return generatedId;
            }
         catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        return null;
	}

}